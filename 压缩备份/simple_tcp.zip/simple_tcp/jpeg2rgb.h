#ifndef _JPG2RGB_H_
#define _JPG2RGB_H_

extern int jpg2rgb(unsigned char *srcBuf, int src_size, unsigned char *dstBuf);

#endif
